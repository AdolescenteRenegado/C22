# PRO-C22-wireframe
wire frame for c22 
